const navbar = document.getElementById('navbarmenu')
const menubtn = document.querySelector('#menubar')
const clos = document.getElementById('close')


menubtn.addEventListener('click',()=>{
  clos.classList.remove('hidden')
  menubtn.classList.add('hidden')
  navbar.style.height = '250px'
  main.style.transition = 'all 0.2s'
  
})
clos.addEventListener('click',()=> {
    clos.classList.add('hidden')
    menubtn.classList.remove('hidden')
    navbar.style.height = '0px'

})
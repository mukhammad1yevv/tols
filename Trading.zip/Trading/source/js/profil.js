const pi = document.getElementById('img')
const image = document.getElementById('image')

pi.addEventListener('mouseover',()=> {
    pi.style.opacity = '0.5'
    image.classList.remove('hidden')
    pi.style.transition = 'all 0.5s'
    setTimeout(()=>{
        pi.style.transition = 'all 0.5s'
        image.classList.add('hidden')
        pi.style.opacity = '1'
    },3000)
})

const navbar = document.getElementById('navbarmenu')
const menubtn = document.querySelector('#menubar')
const clos = document.getElementById('close')
const main = document.getElementById('main')


menubtn.addEventListener('click',()=>{
  clos.classList.remove('hidden')
  menubtn.classList.add('hidden')
  navbar.style.height = '250px'
  main.style.opacity = '0.2'
  main.style.transition = 'all 0.2s'
  
})
clos.addEventListener('click',()=> {
    clos.classList.add('hidden')
    menubtn.classList.remove('hidden')
    navbar.style.height = '0px'
    main.style.opacity = '1'

})